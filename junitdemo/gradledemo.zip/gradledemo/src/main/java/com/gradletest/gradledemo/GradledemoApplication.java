package com.gradletest.gradledemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradledemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GradledemoApplication.class, args);
	}

}
